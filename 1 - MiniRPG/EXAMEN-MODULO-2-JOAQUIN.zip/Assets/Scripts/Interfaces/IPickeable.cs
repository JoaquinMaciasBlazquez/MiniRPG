public interface IPickeable {
    public abstract void PickUp();
}